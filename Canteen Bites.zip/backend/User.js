const mongoose = require('mongoose');
const EMAIL_REGEX = /^(?!.*\.\.)[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;

const userSchema = new mongoose.Schema({
  canID: { type: String, required: true, index: true },
  name: { type: String, required: true, trim: true },
  email: {
    type: String,
    required: true,
    trim: true,
    lowercase: true,
    match: [EMAIL_REGEX, 'Please provide a valid email address']
  },
  password: {
    type: String,
    required: true,
    minlength: [8, 'Password must be at least 8 characters']
  }
});

userSchema.index({ canID: 1, email: 1 }, { unique: true });

module.exports = mongoose.model('User', userSchema);
